//
//  ViewController.swift
//  Letsplay2
//
//  Created by Devanaboyina,Maneesh on 4/4/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
   
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        collectionView.register(TimingCollectionViewCell.nib(), forCellWithReuseIdentifier: TimingCollectionViewCell.identifier)
        collectionView.delegate=self
        collectionView.dataSource=self
        
        
    }
    
    
    @IBAction func datePickerChanged(_ sender: Any) {
        
        let dateFormatter = DateFormatter()

            dateFormatter.dateStyle = DateFormatter.Style.short
            dateFormatter.timeStyle = DateFormatter.Style.short

            let strDate = dateFormatter.string(from: datePicker.date)
            //datePicker.text = strDate
        
        let date = datePicker.date
     //  if
    }
    

}

extension ViewController: UICollectionViewDelegate{
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        
        print("Tapped")
    }
    
}

extension ViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 8
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell=collectionView.dequeueReusableCell(withReuseIdentifier: TimingCollectionViewCell.identifier, for: indexPath) as! TimingCollectionViewCell
        cell.setButtonTitle("8AM-9AM")
        return cell
    }
    
    
}

//extension ViewController: UICollectionViewDelegateFlowLayout{}
